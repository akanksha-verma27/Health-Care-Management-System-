package com.java.provider;

public enum Status {
	CONFIRMED, CANCELED, PENDING
}
