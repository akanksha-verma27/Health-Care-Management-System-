package com.java.provider;

import java.text.ParseException;

public class Test {
	public static void main(String[] args) {
//		PatientAppointmentDAO dao = new PatientAppointmentDaoImpl();
//		
//		try {
//			System.out.println(dao.showPatientAppointmentDao());
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		PatientEnrollmentDAO dao1 = new PatientEnrollmentDaoImpl();
//		System.out.println(dao1.searchPatientEnrollment("P001"));
	}
}
