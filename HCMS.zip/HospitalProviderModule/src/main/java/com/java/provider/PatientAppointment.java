package com.java.provider;

import java.util.Date;

public class PatientAppointment {
	
    private String appointmentId;
    private String providerId;
    private String uhid;
    private String firstName;
    private String lastName;
    private Date appointmentDate;
    private String appointmentTime;
    private Status status;
	
    public PatientAppointment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatientAppointment(String appointmentId, String providerId, String uhid, String firstName, String lastName,
			Date appointmentDate, String appointmentTime, Status status) {
		super();
		this.appointmentId = appointmentId;
		this.providerId = providerId;
		this.uhid = uhid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
		this.status = status;
	}

	
	
	
	@Override
	public String toString() {
		return "PatientAppointment [appointmentId=" + appointmentId + ", providerId=" + providerId + ", uhid=" + uhid
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", appointmentDate=" + appointmentDate
				+ ", appointmentTime=" + appointmentTime + ", status=" + status + "]";
	}

	public String getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(String appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getUhid() {
		return uhid;
	}

	public void setUhid(String uhid) {
		this.uhid = uhid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getAppointmentTime() {
		return appointmentTime;
	}

	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}
    
}
