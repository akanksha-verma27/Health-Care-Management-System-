package com.java.provider;

public interface PatientEnrollmentDAO {
	PatientEnrollment searchPatientEnrollment(String uhid);
}
