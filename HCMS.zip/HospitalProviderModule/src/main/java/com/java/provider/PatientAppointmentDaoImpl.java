package com.java.provider;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

public class PatientAppointmentDaoImpl implements PatientAppointmentDAO{
	
	SessionFactory sf;
	Session session;
	
	private String searchValue;
	
	public String getSearchValue() {
		return searchValue;
	}
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	
	private String searchType;

	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public void searchTypeChanged(ValueChangeEvent e) {
		this.searchType = e.getNewValue().toString();
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		sessionMap.put("searchTypeStr", this.searchType);
	}
	
	public List<String> getsearchTypes(){
		List<String> searchTypeList= new ArrayList<>();
		
		searchTypeList.add("All");
		searchTypeList.add("patientId");
		searchTypeList.add("Name");
		searchTypeList.add("Date");
		searchTypeList.add("Time");
		return searchTypeList;
	}

//	@Override
//	public List<PatientAppointment> showPatientAppointmentDao(int firstRow, int rowCount, String searchValue) {
//		Status status = Status.valueOf("PENDING");
//		SessionFactory sf = SessionHelper.getConnection();
//		Session session = sf.openSession();
//		List<PatientAppointment> cdList = null;
//			session.beginTransaction();
//			Criteria criteria = session.createCriteria(PatientAppointment.class);
//			criteria.add(Restrictions.eq("providerId", "D001"));
//			criteria.add(Restrictions.eq("status", status));
//			System.out.println(searchValue);
//			if(searchValue!=null) {
//				criteria.add(Restrictions.like("firstName", searchValue));
//			}
//			
//			criteria.setFirstResult(firstRow);
//			criteria.setMaxResults(rowCount);
//			System.out.println("list : "+criteria.list());
//		return criteria.list();
//	}

//	@Override
//	public List<PatientAppointment> showPatientAppointmentDao(String searchValue) {
//		Status status = Status.valueOf("PENDING");
//		System.out.println("type : "+this.searchType);
//		SessionFactory sf = SessionHelper.getConnection();
//		Session session = sf.openSession();
//		Criteria criteria = session.createCriteria(PatientAppointment.class);
//		criteria.add(Restrictions.eq("providerId", "D001"));
//		criteria.add(Restrictions.eq("status", status));
//		System.out.println("search value is : "+searchValue);
//		if(searchType!=null) {
//		if(this.searchType.equals("Date")) {
//			criteria.add(Restrictions.like("firstName", searchValue));			
//		}else if(this.searchType.equals("Name")) {			
//			criteria.add(Restrictions.like("firstName", searchValue));
//		}else {
//			System.out.println("all");
//		}
//	}
//		System.out.println("list : "+criteria.list());
//		return criteria.list();
//	}
	
	public List<PatientAppointment> showDefault() {
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(PatientAppointment.class);
		return criteria.list();
	}
	
	@Override
	public List<PatientAppointment> searchPatientAppointmentDao(int firstRow, int rowCount, String searchValue) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		String searchTypeStr = (String) sessionMap.get("searchTypeStr");
		Status status = Status.valueOf("PENDING");
		System.out.println("type : "+searchTypeStr);
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(PatientAppointment.class);
		criteria.add(Restrictions.eq("providerId", "D001"));
		criteria.add(Restrictions.eq("status", status));
		System.out.println("search value is : "+searchValue);
		if(searchTypeStr!=null) {
		if(searchTypeStr.equals("Name") && searchValue.length()!=0) {
			criteria.add(Restrictions.like("firstName", "%"+searchValue+"%"));			
		}else if(searchTypeStr.equals("patientId") && searchValue.length()!=0) {
			criteria.add(Restrictions.like("uhid", searchValue+"%"));
		}else if(searchTypeStr.equals("Date") && searchValue.length()!=0) {
				Instant search = Instant.parse(searchValue);
				System.out.println(search);
				criteria.add(Restrictions.like("appointmentDate", search+"%"));
			
		}else if(searchTypeStr.equals("Time") && searchValue.length()!=0) {
			criteria.add(Restrictions.like("appointmentTime", searchValue));			
		}else {
			System.out.println("all");
		}
	}
		criteria.setFirstResult(firstRow);
		criteria.setMaxResults(rowCount);
		System.out.println("list : "+criteria.list());
		return criteria.list();
	}
	
	
	
	public int countRows(String searchValue) {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		String searchTypeStr = (String) sessionMap.get("searchTypeStr");
		Status status = Status.valueOf("PENDING");
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		try {
			session.beginTransaction();
			Criteria criteria = session.createCriteria(PatientAppointment.class);
			criteria.add(Restrictions.eq("status", status));
			if(searchTypeStr!=null) {
				if(searchTypeStr.equals("Name")) {
					criteria.add(Restrictions.like("firstName", searchValue));			
				}else if(searchTypeStr.equals("patientId")) {
					criteria.add(Restrictions.like("uhid", searchValue));			
				}else if(searchTypeStr.equals("Date")) {
					criteria.add(Restrictions.like("appointmentDate", searchValue));
				}else if(searchTypeStr.equals("Time")) {
					criteria.add(Restrictions.like("appointmentTime", searchValue));			
				}else {
					System.out.println("all");
				}
			}
			if (criteria != null) {
				return criteria.list().size();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	
	
//	// Start
//	@Override
//	public List<PatientAppointment> showPatientAppointmentDao() throws ParseException {
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//		Status status = Status.valueOf("PENDING");
//		sf = SessionHelper.getConnection();
//		session = sf.openSession();
//		Criteria criteria = session.createCriteria(PatientAppointment.class);
//		criteria.add(Restrictions.eq("providerId", "D001"));
//		criteria.add(Restrictions.eq("status", status));
//		List<PatientAppointment> appointmentList =  criteria.list();
//		System.out.println("Test : "+appointmentList);
//		return appointmentList;
//	}
	
	public String redirectToAppointmentDetails(String appointmentId, String uhid) throws ParseException{
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		searchAppointmentDetails(appointmentId);

		PatientEnrollmentDAO dao = new PatientEnrollmentDaoImpl();
		PatientEnrollment enrollmentFound  = dao.searchPatientEnrollment(uhid);
		sessionMap.put("enrollmentFound", enrollmentFound);
		System.out.println("enr "+enrollmentFound);
		return "AppointmentDetails.jsp?faces-redirect=true";
	}
	
	public PatientAppointment searchAppointmentDetails(String appointmentId) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria criteria = session.createCriteria(PatientAppointment.class);
		criteria.add(Restrictions.eq("appointmentId", appointmentId));
		PatientAppointment appointmentDetail =  (PatientAppointment) criteria.uniqueResult();
		sessionMap.put("appointmentDetail", appointmentDetail);
		return appointmentDetail;
	}
	
	public String confirmAppointment(String appointmentId) throws ParseException {
		System.out.println("APPOINTMENTID "+appointmentId);
		PatientAppointment appointmenFound = searchAppointmentDetails(appointmentId);
		appointmenFound.setStatus(Status.valueOf("CONFIRMED"));
		System.out.println("APPOINTMENFOUND "+appointmenFound);
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans = session.beginTransaction();
		session.update(appointmenFound);
		trans.commit();
		
		return "ShowPatientAppointmentNew.jsp?faces-redirect=true";
	}
	public String cancelAppointment(String appointmentId) throws ParseException {
		PatientAppointment appointmenFound = searchAppointmentDetails(appointmentId);
		appointmenFound.setStatus(Status.valueOf("CANCELED"));
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans = session.beginTransaction();
		session.update(appointmenFound);
		trans.commit();
		
		return "ShowPatientAppointmentNew.jsp?faces-redirect=true";
	}
	
}
